toScript='~/Dropbox/Dadi_tuto/SFS_FOLDED/scripts/2.inference_SFS'
toFold='~/Dropbox/Dadi_tuto/SFS_FOLDED/results'
toFS='~/Dropbox/Dadi_tuto/SFS_FOLDED/data'

#For example, to run Strict Isolation (SI) 50 times
for i in {1..50}; do
	cd ${toFold}
	python ${toScript}/script_inference_anneal2_newton_0.py -o SI -y am -x stl -f ${toFS}/am_stl.fs -m SI -z -l -p 15 25 40
done
