
#Change input parameters in file SNP2fs.py

toScript='~/Dropbox/Dadi_tuto/SFS_FOLDED/scripts/1.extract_SFS_from_DADI'
python ${toScript}/SNP2fs.py

