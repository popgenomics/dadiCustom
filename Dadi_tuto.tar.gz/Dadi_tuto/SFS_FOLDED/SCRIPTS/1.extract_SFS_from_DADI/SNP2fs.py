# -*- coding: utf-8 -*-

#####################################################################
#                                                                   #
#                            SNP2fs                                 #
#                                                                   #
#####################################################################

### Extract a frequency spectrum from a SNP data file

#Import library
import os
import dadi
import pylab

#Input
Out_name = "am_stl"
NomPop1 = "am"
NomPop2 = "stl"
N_ind1 = 7
N_ind2 = 7

#Extract the jSFS
dd = dadi.Misc.make_data_dict((Out_name + "_dadi.txt"))
fs = dadi.Spectrum.from_data_dict(dd, [NomPop1,NomPop2], [N_ind1*2, N_ind2*2], polarized = False)
fs.to_file(Out_name + ".fs")
dadi.Plotting.plot_single_2d_sfs(fs, vmin=0.1)
pylab.show()



