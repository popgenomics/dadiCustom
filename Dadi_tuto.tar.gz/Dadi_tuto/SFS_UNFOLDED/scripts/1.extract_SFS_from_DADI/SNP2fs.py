# -*- coding: utf-8 -*-

#####################################################################
#                                                                   #
#                            SNP2fs                                 #
#                                                                   #
#####################################################################

### Extract a frequency spectrum from a SNP data file

#Import library
import os
import dadi
import pylab

#Input
Out_name = "gal_edu"
NomPop1 = "gal"
NomPop2 = "edu"
N_ind1 = 4
N_ind2 = 4

#Extract the jSFS
dd = dadi.Misc.make_data_dict((Out_name + "_dadi.txt"))
fs = dadi.Spectrum.from_data_dict(dd, [NomPop1,NomPop2], [N_ind1*2, N_ind2*2], polarized = True)
fs.to_file(Out_name + ".fs")
dadi.Plotting.plot_single_2d_sfs(fs, vmin=0.1)
pylab.show()



