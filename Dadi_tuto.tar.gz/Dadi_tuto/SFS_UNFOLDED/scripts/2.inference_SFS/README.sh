toScript='~/Dropbox/Dadi_tuto/SFS_UNFOLDED/scripts/2.inference_SFS'
toFold='~/Dropbox/Dadi_tuto/SFS_UNFOLDED/results'
toFS='~/Dropbox/Dadi_tuto/SFS_UNFOLDED/data'

#For example, to run Strict Isolation (SI) 50 times
for i in {1..50}; do
	cd ${toFold}
	python ${toScript}/script_inference_anneal2_newton_mis_0.py -o SI -y gal -x edu -f ${toFS}/gal_edu.fs -m SI -z -l -p 8 16 32
done
